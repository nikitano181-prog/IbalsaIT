#pragma once
#include <iostream>
using namespace std;
void input(float*& a, int& n, int s);
float searchmax(float a[], int n);
int searchind(float a[], int &n, float maxi);
float zero(float a[], int &n);
float sum(float a[], int ind);
int searchind2(float a[], int &n, float maxi);
void movenumbers(float a[], int &n);
void modul(float a[], int &n, float l, float h);
void fq(float *a, int &n, int sem);
int jjj( float a[], int n ,float m);
void sq(float *a, int &n, int sem);
void tq(float* a ,int &n, int sem);

#include "output.h"
