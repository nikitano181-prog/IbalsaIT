#include "files.h"
int main()
{
    while (true)
    {
       int n;
        float* a = nullptr;
        int sem;
        cout  <<"введите номер семинара(1-3) " <<endl <<"0 - выход" <<endl;
        cin >> sem;
        if(sem > 3)
        {
                cout <<"введите верный номер задания" << endl;
            }
        switch(sem){
            case 0:
                return 0;
            case 1:
            {
                fq(a, n, sem);
                break;
            }    
            case 2:
            {
                sq(a,n,sem);
                break;
            }
            case 3:
            {
                tq(a,n, sem);
                break;
            }
        }
    }
    return 0;
}